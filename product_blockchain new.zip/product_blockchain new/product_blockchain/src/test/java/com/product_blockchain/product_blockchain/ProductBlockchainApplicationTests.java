package com.product_blockchain.product_blockchain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductBlockchainApplicationTests {

	@Test
	void contextLoads() {
	}

}
