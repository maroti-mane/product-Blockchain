package com.product_blockchain.product_blockchain.service;



public class PngCRC {

    private static final int[] CRC_TABLE = new int[256];

    static {
        for (int i = 0; i < 256; i++) {
            int c = i;
            for (int k = 0; k < 8; k++) {
                if ((c & 1) == 1) c = 0xEDB88320 ^ (c >>> 1);
                else c = c >>> 1;
            }
            CRC_TABLE[i] = c;
        }
    }

    public static int crc(byte[] type, byte[] data) {
        int c = 0xFFFFFFFF;

        for (byte b : type) {
            c = CRC_TABLE[(c ^ b) & 0xFF] ^ (c >>> 1);
        }

        for (byte b : data) {
            c = CRC_TABLE[(c ^ b) & 0xFF] ^ (c >>> 1);
        }

        return c ^ 0xFFFFFFFF;
    }
}

