package com.product_blockchain.product_blockchain.service;

import java.io.ByteArrayOutputStream;
import java.util.zip.Deflater;

public class PngZlib {

    public static byte[] compress(byte[] pixels, int width, int height) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            // Add filter byte 0 for each row
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            int index = 0;

            for (int y = 0; y < height; y++) {
                raw.write(0); // filter type 0
                for (int x = 0; x < width; x++) {
                    raw.write(pixels[index++] & 0xFF);
                }
            }

            byte[] rawData = raw.toByteArray();

            // Compress using zlib
            Deflater deflater = new Deflater();
            deflater.setInput(rawData);
            deflater.finish();

            byte[] buffer = new byte[4096];
            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                out.write(buffer, 0, count);
            }

            deflater.end();

            return out.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Zlib compression error", e);
        }
    }
}

