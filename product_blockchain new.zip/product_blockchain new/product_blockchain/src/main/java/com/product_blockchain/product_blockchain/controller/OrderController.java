package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.OrderResponseDTO;
import com.product_blockchain.product_blockchain.dto.TransportAssignRequest;
import com.product_blockchain.product_blockchain.entity.Order;
import com.product_blockchain.product_blockchain.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")

public class OrderController {

    @Autowired
    private OrderService orderService;

    // PLACE ORDER
    @PostMapping("/place/{retailerId}")
    public ResponseEntity<OrderResponseDTO> placeOrder(@PathVariable Long retailerId) {
        Order savedOrder = orderService.placeOrder(retailerId);
        return ResponseEntity.ok(orderService.getOrderDetails(savedOrder.getId()));
    }




    // GET RETAILER ORDERS
    @GetMapping("/retailer/{retailerId}")
    public ResponseEntity<List<OrderResponseDTO>> getOrdersByRetailer(@PathVariable Long retailerId) {
        return ResponseEntity.ok(orderService.getOrdersByRetailer(retailerId));
    }

    // ORDER DETAILS
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponseDTO> getOrderDetails(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.getOrderDetails(orderId));
    }

    // ASSIGN TRANSPORT
    @PostMapping("/assign-transport/{orderId}")
    public ResponseEntity<OrderResponseDTO> assignTransport(
            @PathVariable Long orderId,
            @RequestBody TransportAssignRequest request
    ) {
        Order updated = orderService.assignTransport(orderId, request);
        return ResponseEntity.ok(orderService.getOrderDetails(updated.getId()));
    }

    // UPDATE STATUS
    @PutMapping("/update-status/{orderId}")
    public ResponseEntity<OrderResponseDTO> updateOrderStatus(
            @PathVariable Long orderId,
            @RequestParam String status
    ) {
        Order updated = orderService.updateOrderStatus(orderId, status);
        return ResponseEntity.ok(orderService.getOrderDetails(updated.getId()));
    }



    // FARMER ORDERS
    @GetMapping("/farmer/{farmerId}/orders")
    public ResponseEntity<List<Order>> getFarmerOrders(@PathVariable Long farmerId) {
        return ResponseEntity.ok(orderService.getOrdersForFarmer(farmerId));
    }

    // ✅ FINAL — TRANSPORTER ORDERS (Only One!)
    @GetMapping("/transporter/{transporterId}")
    public ResponseEntity<List<OrderResponseDTO>> getOrdersForTransporter(
            @PathVariable Long transporterId) {
        return ResponseEntity.ok(orderService.getOrdersForTransporter(transporterId));
    }



}