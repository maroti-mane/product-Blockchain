package com.product_blockchain.product_blockchain.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:3000") // React frontend
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        // ==============================================================
        // PRODUCT IMAGES  →   /uploads/**
        // ==============================================================
        Path uploadDir = Paths.get(System.getProperty("user.dir"), "uploads");
        String uploadPath = uploadDir.toFile().getAbsolutePath();

        System.out.println("=== Static Resource Mapping ===");
        System.out.println("Images served from: " + uploadPath);
        System.out.println("URL path: http://localhost:8080/uploads/...");

        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + uploadPath + "/")
                .setCachePeriod(3600);

        // ==============================================================
        // QR CODE IMAGES  →   /qr/**
        // ==============================================================
        Path qrDir = Paths.get(System.getProperty("user.dir"), "uploads", "qr");
        String qrPath = qrDir.toFile().getAbsolutePath();

        System.out.println("QR Codes served from: " + qrPath);
        System.out.println("URL path: http://localhost:8080/uploads/    qr/...");

        registry.addResourceHandler("/qr/**")
                .addResourceLocations("file:" + qrPath + "/")
                .setCachePeriod(3600);
    }
}
