package com.product_blockchain.product_blockchain.dto;

import java.time.LocalDateTime;
import java.util.List;

public class OrderResponseDTO {

    private Long orderId;
    private LocalDateTime createdAt;
    private Double totalAmount;
    private String paymentMethod;
    private String paymentStatus;
    private String status;

    private List<OrderItemDTO> items;

    private Long retailerId;
    private String retailerName;

    private String farmerName;

    private Long transporterId;
    private String vehicleType;
    private String vehicleNo;
    private String driverName;
    private String driverContact;


    private LocalDateTime deliveredDate;

    public OrderResponseDTO() {}

    public OrderResponseDTO(Long orderId, LocalDateTime createdAt, Double totalAmount,
                            String paymentMethod, String paymentStatus, String status,
                            List<OrderItemDTO> items, Long retailerId, String retailerName,
                            String farmerName, Long transporterId, String vehicleType,
                            String vehicleNo, String driverName, String driverContact,
                           LocalDateTime deliveredDate) {
        this.orderId = orderId;
        this.createdAt = createdAt;
        this.totalAmount = totalAmount;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
        this.status = status;
        this.items = items;
        this.retailerId = retailerId;
        this.retailerName = retailerName;
        this.farmerName = farmerName;
        this.transporterId = transporterId;
        this.vehicleType = vehicleType;
        this.vehicleNo = vehicleNo;
        this.driverName = driverName;
        this.driverContact = driverContact;
        this.deliveredDate = deliveredDate;
    }

    // ===================== GETTERS & SETTERS =====================

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public List<OrderItemDTO> getItems() { return items; }
    public void setItems(List<OrderItemDTO> items) { this.items = items; }

    public Long getRetailerId() { return retailerId; }
    public void setRetailerId(Long retailerId) { this.retailerId = retailerId; }

    public String getRetailerName() { return retailerName; }
    public void setRetailerName(String retailerName) { this.retailerName = retailerName; }

    public String getFarmerName() { return farmerName; }
    public void setFarmerName(String farmerName) { this.farmerName = farmerName; }

    public Long getTransporterId() { return transporterId; }
    public void setTransporterId(Long transporterId) { this.transporterId = transporterId; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getVehicleNo() { return vehicleNo; }
    public void setVehicleNo(String vehicleNo) { this.vehicleNo = vehicleNo; }

    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }

    public String getDriverContact() { return driverContact; }
    public void setDriverContact(String driverContact) { this.driverContact = driverContact; }

    public LocalDateTime getDeliveredDate() { return deliveredDate; }
    public void setDeliveredDate(LocalDateTime deliveredDate) { this.deliveredDate = deliveredDate; }
}
