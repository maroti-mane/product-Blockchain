package com.product_blockchain.product_blockchain.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.product_blockchain.product_blockchain.dto.ProductDTO;
import com.product_blockchain.product_blockchain.entity.Product;
import com.product_blockchain.product_blockchain.repository.ProductRepository;
import com.product_blockchain.product_blockchain.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductRepository productRepository;

    // =======================================
    // ADD PRODUCT (JSON + FILE UPLOAD)
    // =======================================
    @PostMapping(value = "/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> addProduct(
            @RequestPart("product") String productJson,
            @RequestPart(value = "image", required = false) MultipartFile image) {

        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());

            ProductDTO productDTO = mapper.readValue(productJson, ProductDTO.class);

            if (productDTO.getFarmerEmail() == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Farmer email is required"));
            }

            try {
                File f = new File("D:/data.txt");
                FileWriter fw = new FileWriter(f);
                String data = productDTO.getName() + "#" + productDTO.getFarmerEmail();
                fw.write(data);
                fw.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            ProductDTO savedProduct = productService.addProduct(productDTO, image, productDTO.getFarmerEmail());
            return ResponseEntity.ok(savedProduct);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // =======================================
    // GET PRODUCTS BY FARMER EMAIL
    // =======================================
    @GetMapping("/my/{email}")
    public ResponseEntity<?> getProductsByFarmer(@PathVariable String email) {
        List<ProductDTO> products = productService.getProductsByFarmer(email);
        return ResponseEntity.ok(products);
    }

    // =======================================
    // GET PRODUCTS BY FARMER ID
    // =======================================
    @GetMapping("/farmer/{farmerId}")
    public ResponseEntity<?> getProductsByFarmerId(@PathVariable Long farmerId) {
        List<Product> products = productRepository.findByFarmerId(farmerId);
        return ResponseEntity.ok(products);
    }

    // =======================================
    // GET ALL PRODUCTS
    // =======================================
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productRepository.findAll());
    }

    // =======================================
    // GET PRODUCT BY ID
    // =======================================
    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable Long id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }

    // =======================================
    // GET PRODUCTS FOR A RETAILER (USER VIEW)
    // =======================================
    @GetMapping("/retailer/{retailerId}")
    public ResponseEntity<?> getProductsByRetailer(@PathVariable Long retailerId) {
        return ResponseEntity.ok(productService.getProductsByRetailer(retailerId));
    }
}
