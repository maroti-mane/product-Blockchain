package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.PurchaseDTO;
import com.product_blockchain.product_blockchain.dto.PurchaseRequest;

public interface PurchaseService {
    PurchaseDTO buyProduct(PurchaseRequest request);
}
