package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.RetailerSignupRequest;
import com.product_blockchain.product_blockchain.dto.RetailerLoginRequest;
import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.service.RetailerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/retailer/auth")

public class RetailerAuthController {

    @Autowired
    private RetailerService retailerService;

    // ==========================================================
    // ✅ SIGNUP
    // ==========================================================
    @PostMapping("/signup")
    public ResponseEntity<?> registerRetailer(@RequestBody RetailerSignupRequest signupRequest) {
        try {
            Retailer retailer = retailerService.registerRetailer(signupRequest);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Retailer registered successfully!");
            response.put("retailerId", retailer.getId());
            response.put("storeName", retailer.getStoreName());
            response.put("email", retailer.getEmail());

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Unexpected error occurred"));
        }
    }

    // ==========================================================
    // ✅ LOGIN
    // ==========================================================
    @PostMapping("/login")
    public ResponseEntity<?> loginRetailer(@RequestBody RetailerLoginRequest loginRequest) {
        try {
            Retailer retailer = retailerService.getRetailerByEmail(loginRequest.getEmail());

            if (!retailerService.checkPassword(loginRequest.getPassword(), retailer.getPassword())) {
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid credentials"));
            }

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login successful!");
            response.put("retailerId", retailer.getId());
            response.put("storeName", retailer.getStoreName());
            response.put("ownerName", retailer.getOwnerName());
            response.put("email", retailer.getEmail());

            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Unexpected error occurred"));
        }
    }

}
