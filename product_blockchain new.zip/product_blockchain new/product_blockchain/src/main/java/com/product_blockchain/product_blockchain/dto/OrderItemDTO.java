package com.product_blockchain.product_blockchain.dto;

public class OrderItemDTO {

    private String productName;
    private Integer quantity;
    private Double price;
    private Double total;
    private String farmerName;

    public OrderItemDTO() {
    }

    public OrderItemDTO(String productName, Integer quantity, Double price, Double total, String farmerName) {
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
        this.total = total;
        this.farmerName = farmerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setFarmerName(String farmerName) {
        this.farmerName = farmerName;
    }
}
