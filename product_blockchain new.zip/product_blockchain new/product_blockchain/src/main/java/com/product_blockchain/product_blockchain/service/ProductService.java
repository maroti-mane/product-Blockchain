package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.ProductDTO;
import com.product_blockchain.product_blockchain.entity.Product;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ProductService {

    // Add a new product for a farmer
    ProductDTO addProduct(ProductDTO productDTO, MultipartFile imageFile, String farmerEmail) throws IOException;

    // Get all products created by a specific farmer
    List<ProductDTO> getProductsByFarmer(String farmerEmail);

    // Get product by ID
    ProductDTO getProductById(Long id);

    // Get all products
    List<ProductDTO> getAllProducts();

    // Get products by category
    List<ProductDTO> getProductsByCategory(String category);

    // ⭐ Retailer's purchased stock
    List<Product> getRetailerStock(Long retailerId);

    // ⭐ NEW — Required by ProductController
    List<ProductDTO> getProductsByRetailer(Long retailerId);
}
