package com.product_blockchain.product_blockchain.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name = "cart_items")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ---------- PRODUCT RELATION ----------
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id")
    @JsonIgnoreProperties({"cartItems"})
    private Product product;

    // Quantity of product
    private Integer quantity;

    // ---------- RETAILER RELATION ----------
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "retailer_id")
    @JsonIgnoreProperties({"cartItems"})
    private Retailer retailer;

    // ---------- ORDER RELATION ----------
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    @JsonIgnoreProperties({"items"})
    private Order order;

    // ============================================================
    // CONSTRUCTORS
    // ============================================================
    public CartItem() {}

    public CartItem(Long id, Product product, Integer quantity, Retailer retailer, Order order) {
        this.id = id;
        this.product = product;
        this.quantity = quantity;
        this.retailer = retailer;
        this.order = order;
    }

    // ============================================================
    // GETTERS & SETTERS
    // ============================================================
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Retailer getRetailer() {
        return retailer;
    }

    public void setRetailer(Retailer retailer) {
        this.retailer = retailer;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
}
