package com.product_blockchain.product_blockchain.service;

import com.google.zxing.WriterException;
import com.product_blockchain.product_blockchain.dto.ProductDTO;
import com.product_blockchain.product_blockchain.entity.CartItem;
import com.product_blockchain.product_blockchain.entity.Farmer;
import com.product_blockchain.product_blockchain.entity.Order;
import com.product_blockchain.product_blockchain.entity.Product;
import com.product_blockchain.product_blockchain.repository.FarmerRepository;
import com.product_blockchain.product_blockchain.repository.OrderRepository;
import com.product_blockchain.product_blockchain.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private FarmerRepository farmerRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private QRGeneratorService qrGeneratorService;

    // ====================================================
    // ADD PRODUCT (Farmer)
    // ====================================================
    @Override
    public ProductDTO addProduct(ProductDTO dto, MultipartFile imageFile, String farmerEmail) throws IOException {

        Farmer farmer = farmerRepository.findByEmail(farmerEmail)
                .orElseThrow(() -> new RuntimeException("Farmer not found: " + farmerEmail));

        String imagePath = null;

        if (imageFile != null && !imageFile.isEmpty()) {
            String uploadDir = System.getProperty("user.dir") + "/uploads/";
            File uploadFolder = new File(uploadDir);
            if (!uploadFolder.exists()) uploadFolder.mkdirs();

            String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
            Path filePath = Paths.get(uploadDir + fileName);
            Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            imagePath = fileName;
        }

        Product product = new Product();
        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setPrice(dto.getPrice());
        product.setBatchNumber(dto.getBatchNumber());
        product.setProductionDate(dto.getProductionDate());
        product.setDescription(dto.getDescription());
        product.setImagePath(imagePath);
        product.setFarmer(farmer);
        product.setQuantity(dto.getQuantity());

        Product saved = productRepository.save(product);
        long pid=saved.getId();
        String name = saved.getName();
        String category = saved.getCategory();
        Double price = saved.getPrice();
        String batchNumber = saved.getBatchNumber();
        String productionDate = saved.getProductionDate().toString();
        String description = saved.getDescription();
        String image = saved.getImagePath();
        String farmerName = saved.getFarmer() != null ? saved.getFarmer().getName() : "";
        int quantity = saved.getQuantity();


        try {
            //String qrData = "http://localhost:3000/product/qr/" + saved.getId();
            String qrData = pid + "#" +
                    name + "#" +
                    category + "#" +
                    price + "#" +
                    batchNumber + "#" +
                    productionDate + "#" +
                    description + "#" +
                    image + "#" +
                    farmerName + "#" +
                    quantity + "#";
            String qrPath = qrGeneratorService.generateQRCode(qrData, saved.getId());
            saved.setQrCodePath(qrPath);
            File f = new File("D:/product_details.txt");
            FileWriter fw = new FileWriter(f);

            fw.write(qrData);
            fw.close();
        } catch (WriterException e) {
            throw new IOException("Failed to generate QR Code", e);
        }
        try {
            File f = new File("D:/task.txt");
            FileWriter fw = new FileWriter(f);

            fw.write("product_qr_details");
            fw.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        saved = productRepository.save(saved);
        return convertToDTO(saved);
    }

    // ====================================================
    // GET FARMER PRODUCTS
    // ====================================================
    @Override
    public List<ProductDTO> getProductsByFarmer(String email) {
        Farmer farmer = farmerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Farmer not found"));

        return productRepository.findByFarmerId(farmer.getId())
                .stream().map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ====================================================
    // GET PRODUCT BY ID
    // ====================================================
    @Override
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return convertToDTO(product);
    }

    // ====================================================
    // ⭐ USER → Retailer → Retailer Stock
    // ====================================================
    @Override
    public List<Product> getRetailerStock(Long retailerId) {

        List<Order> orders = orderRepository.findByRetailer_Id(retailerId);

        List<Product> products = new ArrayList<>();

        for (Order order : orders) {
            for (CartItem item : order.getItems()) {
                Product p = item.getProduct();
                if (p != null) {
                    products.add(p);
                }
            }
        }

        return products;
    }

    // ====================================================
    // GET ALL PRODUCTS
    // ====================================================
    @Override
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll()
                .stream().map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // ====================================================
    // UNUSED
    // ====================================================
    @Override
    public List<ProductDTO> getProductsByCategory(String category) {
        return List.of();
    }

    // ====================================================
    // ENTITY → DTO
    // ====================================================
    private ProductDTO convertToDTO(Product p) {
        ProductDTO dto = new ProductDTO();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setCategory(p.getCategory());
        dto.setPrice(p.getPrice());
        dto.setBatchNumber(p.getBatchNumber());
        dto.setProductionDate(p.getProductionDate());
        dto.setDescription(p.getDescription());
        dto.setImagePath(p.getImagePath());
        dto.setQrCodePath(p.getQrCodePath());
        dto.setCreatedAt(p.getCreatedAt());
        dto.setQuantity(p.getQuantity());

        if (p.getFarmer() != null) {
            dto.setFarmerEmail(p.getFarmer().getEmail());
            dto.setFarmerName(p.getFarmer().getName());
        }
        return dto;
    }

    public List<ProductDTO> getProductsByRetailer(Long retailerId) {
        List<Product> products = productRepository.findByRetailerId(retailerId);
        return products.stream().map(this::convertToDTO).toList();
    }

}
