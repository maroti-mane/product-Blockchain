package com.product_blockchain.product_blockchain.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Retailer relation
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "retailer_id")
    private Retailer retailer;

    @Column(name = "farmer_id")
    private Long farmerId;

    @Column(name = "transporter_id")
    private Long transporterId;

    private String vehicleNo;
    private String driverName;
    private String driverContact;

    @Column(name = "vehicle_type")
    private String vehicleType;

    @Column(name = "total_amount")
    private Double totalAmount;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "delivered_date")
    private LocalDateTime deliveredDate;

    @Column(name = "status")
    private String status; // PROCESSING / DISPATCHED / DELIVERED

    @Column(name = "payment_method")
    private String paymentMethod;

    @Column(name = "payment_status")
    private String paymentStatus; // PAID / PENDING



    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties({"order"})
    private List<CartItem> items;

    // ============================================================
    // CONSTRUCTORS
    // ============================================================
    public Order() {}

    public Order(Long id, Retailer retailer, Long farmerId, Long transporterId,
                 String vehicleNo, String driverName, String driverContact,
                 String vehicleType, Double totalAmount, LocalDateTime createdAt,
                 LocalDateTime deliveredDate, String status, String paymentMethod,
                 String paymentStatus, Boolean retailerConfirmed, List<CartItem> items) {
        this.id = id;
        this.retailer = retailer;
        this.farmerId = farmerId;
        this.transporterId = transporterId;
        this.vehicleNo = vehicleNo;
        this.driverName = driverName;
        this.driverContact = driverContact;
        this.vehicleType = vehicleType;
        this.totalAmount = totalAmount;
        this.createdAt = createdAt;
        this.deliveredDate = deliveredDate;
        this.status = status;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
        this.items = items;
    }

    // ============================================================
    // GETTERS & SETTERS
    // ============================================================
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Retailer getRetailer() { return retailer; }
    public void setRetailer(Retailer retailer) { this.retailer = retailer; }

    public Long getFarmerId() { return farmerId; }
    public void setFarmerId(Long farmerId) { this.farmerId = farmerId; }

    public Long getTransporterId() { return transporterId; }
    public void setTransporterId(Long transporterId) { this.transporterId = transporterId; }

    public String getVehicleNo() { return vehicleNo; }
    public void setVehicleNo(String vehicleNo) { this.vehicleNo = vehicleNo; }

    public String getDriverName() { return driverName; }
    public void setDriverName(String driverName) { this.driverName = driverName; }

    public String getDriverContact() { return driverContact; }
    public void setDriverContact(String driverContact) { this.driverContact = driverContact; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getDeliveredDate() { return deliveredDate; }
    public void setDeliveredDate(LocalDateTime deliveredDate) { this.deliveredDate = deliveredDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }


    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items;
        if(items != null) {
            items.forEach(i -> i.setOrder(this));
        }
    }
}
