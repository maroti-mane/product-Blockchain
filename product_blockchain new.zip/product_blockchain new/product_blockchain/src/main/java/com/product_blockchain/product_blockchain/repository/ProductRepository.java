package com.product_blockchain.product_blockchain.repository;

import com.product_blockchain.product_blockchain.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // ✅ Fetch all products for a specific farmer
    List<Product> findByFarmerId(Long farmerId);

    List<Product> findByRetailerId(Long retailerId);




    // ✅ Fetch products by category (case-insensitive search)
    List<Product> findByCategoryContainingIgnoreCase(String category);
}
