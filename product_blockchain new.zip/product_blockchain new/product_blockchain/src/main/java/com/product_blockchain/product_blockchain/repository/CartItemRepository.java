package com.product_blockchain.product_blockchain.repository;

import com.product_blockchain.product_blockchain.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {

    List<CartItem> findByRetailer_Id(Long retailerId);

    CartItem findByRetailer_IdAndProduct_Id(Long retailerId, Long productId);

    void deleteByRetailer_Id(Long retailerId);
}
