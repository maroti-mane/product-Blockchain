package com.product_blockchain.product_blockchain.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "transport")
public class Transport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String driverName;
    private String contact;
    private String vehicleNo;

    // ASSIGNED, PICKED_UP, DELIVERED
    private String status = "ASSIGNED";

    @ManyToOne
    @JoinColumn(name = "transporter_id")
    private Transporter transporter;

    @OneToOne
    @JoinColumn(name = "order_id")
    private Order order;

    // -----------------------
    // Constructors
    // -----------------------
    public Transport() {
    }

    public Transport(String driverName, String contact, String vehicleNo, String status,
                     Transporter transporter, Order order) {
        this.driverName = driverName;
        this.contact = contact;
        this.vehicleNo = vehicleNo;
        this.status = status;
        this.transporter = transporter;
        this.order = order;
    }

    // -----------------------
    // Getters & Setters
    // -----------------------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Transporter getTransporter() {
        return transporter;
    }

    public void setTransporter(Transporter transporter) {
        this.transporter = transporter;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    // -----------------------
    // toString
    // -----------------------
    @Override
    public String toString() {
        return "Transport{" +
                "id=" + id +
                ", driverName='" + driverName + '\'' +
                ", contact='" + contact + '\'' +
                ", vehicleNo='" + vehicleNo + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
