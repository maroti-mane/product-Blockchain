package com.product_blockchain.product_blockchain.service;

import ar.com.hjg.pngj.ImageInfo;
import ar.com.hjg.pngj.PngWriter;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;

@Service
public class QRGeneratorService {

    public String generateQRCode(String text, Long productId) throws IOException, WriterException {

        int size = 300;

        // Save folder
        String qrFolder = System.getProperty("user.dir") + "/uploads/qr/";
        File folder = new File(qrFolder);
        if (!folder.exists()) folder.mkdirs();

        String fileName = "QR_" + productId + ".png";
        String filePath = qrFolder + fileName;

        // Create QR bitmatrix
        BitMatrix matrix = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size);

        // Write PNG using PNGJ (RGB FIX APPLIED)
        writePngWithPngj(matrix, filePath);

        return "/qr/" + fileName;
    }


    // -----------------------------------------------
    //  FIXED PNG WRITER (RGB MODE — 100% WORKING)
    // -----------------------------------------------
    private void writePngWithPngj(BitMatrix matrix, String path) throws IOException {

        int width = matrix.getWidth();
        int height = matrix.getHeight();

        // PNGJ requires RGB rows (not grayscale)
        ImageInfo info = new ImageInfo(width, height, 8, false);
        PngWriter writer = new PngWriter(new File(path), info);

        for (int y = 0; y < height; y++) {

            int[] rgbRow = new int[width * 3]; // R,G,B for each pixel

            for (int x = 0; x < width; x++) {
                boolean isBlack = matrix.get(x, y);

                int color = isBlack ? 0 : 255;

                // Set RGB
                rgbRow[x * 3] = color;       // R
                rgbRow[x * 3 + 1] = color;   // G
                rgbRow[x * 3 + 2] = color;   // B
            }

            writer.writeRowInt(rgbRow);
        }

        writer.end();
    }
}
