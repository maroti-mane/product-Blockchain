package com.product_blockchain.product_blockchain.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
@Entity
@Table(name = "product_history")
public class ProductHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String action;
    private String description;

    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp = new Date();

    private String transactionHash;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private Product product;

    public ProductHistory() {
        this.transactionHash = generateTransactionHash();
    }

    private String generateTransactionHash() {
        return "0x" + UUID.randomUUID().toString().replace("-", "") +
                Long.toHexString(System.currentTimeMillis());
    }
}
