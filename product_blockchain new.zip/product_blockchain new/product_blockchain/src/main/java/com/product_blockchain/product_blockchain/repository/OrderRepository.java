package com.product_blockchain.product_blockchain.repository;

import com.product_blockchain.product_blockchain.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    // find orders placed by retailer
    List<Order> findByRetailer_Id(Long retailerId);

    // delivered orders for retailer
    List<Order> findByRetailerIdAndStatus(Long retailerId, String status);


    // find by farmer
    List<Order> findByFarmerId(Long farmerId);

    @Query("SELECT o FROM Order o WHERE o.retailer.id = :retailerId AND o.status = 'DELIVERED'")
    List<Order> findDeliveredOrdersByRetailer(@Param("retailerId") Long retailerId);

    // find by transporter
    List<Order> findByTransporterId(Long transporterId);

    @Query("SELECT DISTINCT o FROM Order o " +
            "LEFT JOIN FETCH o.items i " +
            "LEFT JOIN FETCH i.product p " +
            "LEFT JOIN FETCH p.farmer f " +
            "WHERE o.id = :orderId")
    Order findOrderWithItems(@Param("orderId") Long orderId);

}
