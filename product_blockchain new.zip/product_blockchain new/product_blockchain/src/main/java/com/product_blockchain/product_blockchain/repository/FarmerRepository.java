package com.product_blockchain.product_blockchain.repository;


import com.product_blockchain.product_blockchain.entity.Farmer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FarmerRepository extends JpaRepository<Farmer, Long> {

    boolean existsByEmail(String email);

    Optional<Farmer> findByEmail(String email);

    @Query("SELECT DISTINCT f FROM Farmer f LEFT JOIN FETCH f.products")
    List<Farmer> findAllWithProducts();
}


