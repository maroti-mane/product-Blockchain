package com.product_blockchain.product_blockchain.repository;

import com.product_blockchain.product_blockchain.entity.Retailer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RetailerRepository extends JpaRepository<Retailer, Long> {
    Optional<Retailer> findByEmail(String email);
    boolean existsByEmail(String email);
    boolean existsByStoreName(String storeName);
}
