package com.product_blockchain.product_blockchain.dto;



import lombok.Data;

@Data
public class BuyRequest {
    private Long userId;
    private Long productId;
    private int quantity;
}

