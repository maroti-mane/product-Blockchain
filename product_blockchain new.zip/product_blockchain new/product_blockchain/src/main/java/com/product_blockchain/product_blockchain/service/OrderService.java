package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.OrderItemDTO;
import com.product_blockchain.product_blockchain.dto.OrderResponseDTO;
import com.product_blockchain.product_blockchain.dto.TransportAssignRequest;
import com.product_blockchain.product_blockchain.entity.CartItem;
import com.product_blockchain.product_blockchain.entity.Order;
import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.repository.CartItemRepository;
import com.product_blockchain.product_blockchain.repository.OrderRepository;
import com.product_blockchain.product_blockchain.repository.RetailerRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class OrderService {

    @Autowired
    private CartItemRepository cartRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private RetailerRepository retailerRepo;

    // --------------------------------------------------
    // PLACE ORDER
    // --------------------------------------------------
    public Order placeOrder(Long retailerId) {

        List<CartItem> cart = cartRepo.findByRetailer_Id(retailerId);

        if (cart == null || cart.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        Retailer retailer = retailerRepo.findById(retailerId)
                .orElseThrow(() -> new RuntimeException("Retailer not found"));

        Order order = new Order();
        order.setRetailer(retailer);
        order.setFarmerId(cart.get(0).getProduct().getFarmer().getId());

        double total = cart.stream()
                .mapToDouble(c -> c.getProduct().getPrice() * c.getQuantity())
                .sum();

        order.setTotalAmount(total);
        order.setCreatedAt(LocalDateTime.now());
        order.setPaymentMethod("UPI");
        order.setPaymentStatus("PAID");
        order.setStatus("PROCESSING");


        cart.forEach(c -> c.setOrder(order));
        order.setItems(cart);

        Order saved = orderRepo.save(order);

        // ============================================
        // ✨ WRITE ORDER DETAILS TO FILE
        // ============================================
        try {
            File f = new File("D:/order_details.txt");
            FileWriter fw = new FileWriter(f);

            StringBuilder data = new StringBuilder();

            data.append(saved.getId()).append("#")
                    .append(retailer.getId()).append("#")
                    .append(retailer.getStoreName()).append("#")
                    .append(cart.get(0).getProduct().getFarmer().getName()).append("#")
                    .append(saved.getTotalAmount()).append("#")
                    .append(saved.getPaymentMethod()).append("#")
                    .append(saved.getPaymentStatus()).append("#")
                    .append(saved.getCreatedAt()).append("#")
                    .append(saved.getStatus()).append("#");
            fw.write(data.toString());
            fw.close();

            try {
                File f1 = new File("D:/task.txt");
                FileWriter fw1 = new FileWriter(f1);

                fw1.write("product_sale_details");
                fw1.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            // Add product details line-by-line
            for (CartItem item : cart) {
                data.append(item.getProduct().getName()).append("#")
                        .append(item.getQuantity()).append("#")
                        .append(item.getProduct().getPrice()).append("#")
                        .append(item.getProduct().getPrice() * item.getQuantity()).append("#");
            }

            data.append(System.lineSeparator());
            fw.write(data.toString());
            fw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        // ============================================

        cartRepo.deleteByRetailer_Id(retailerId);
        return saved;
    }



    // --------------------------------------------------
    // ASSIGN TRANSPORT
    // --------------------------------------------------
    public Order assignTransport(Long orderId, TransportAssignRequest req) {

        Order order = orderRepo.findOrderWithItems(orderId);
        if (order == null) throw new RuntimeException("Order not found");

        order.setTransporterId(req.getTransporterId());
        order.setVehicleNo(req.getVehicleNo());
        order.setDriverName(req.getDriverName());
        order.setDriverContact(req.getDriverContact());
        order.setStatus("ASSIGNED_TO_TRANSPORTER");

        return orderRepo.save(order);

    }


    // --------------------------------------------------
    // UPDATE ORDER STATUS (Transporter)
    // --------------------------------------------------
    public Order updateOrderStatus(Long orderId, String status) {

        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setStatus(status);

        if ("DELIVERED".equalsIgnoreCase(status)) {
            order.setDeliveredDate(LocalDateTime.now());
        }

        return orderRepo.save(order);

    }

    // --------------------------------------------------
    // GET ORDERS FOR FARMER
    // --------------------------------------------------
    public List<Order> getOrdersForFarmer(Long farmerId) {
        return orderRepo.findByFarmerId(farmerId);
    }


    // --------------------------------------------------
    // GET ORDERS FOR TRANSPORTER
    // --------------------------------------------------
    public List<OrderResponseDTO> getOrdersForTransporter(Long transporterId) {

        List<Order> orders = orderRepo.findByTransporterId(transporterId);

        return orders.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }


    // --------------------------------------------------
    // GET ORDERS FOR RETAILER
    // --------------------------------------------------
    public List<OrderResponseDTO> getOrdersByRetailer(Long retailerId) {
        return orderRepo.findByRetailer_Id(retailerId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());

    }

    // --------------------------------------------------
    // GET ORDER DETAILS
    // --------------------------------------------------
    public OrderResponseDTO getOrderDetails(Long orderId) {

        Order order = orderRepo.findOrderWithItems(orderId);
        if (order == null) throw new RuntimeException("Order not found");

        return mapToDTO(order);
    }


    // --------------------------------------------------
    // MAP ORDER TO DTO
    // --------------------------------------------------
    private OrderResponseDTO mapToDTO(Order order) {

        List<OrderItemDTO> items = order.getItems()
                .stream()
                .map(item -> new OrderItemDTO(
                        item.getProduct() != null ? item.getProduct().getName() : "No Product",
                        item.getQuantity(),
                        item.getProduct() != null ? item.getProduct().getPrice() : 0.0,
                        item.getProduct() != null ? item.getProduct().getPrice() * item.getQuantity() : 0.0,
                        item.getProduct().getFarmer() != null
                                ? item.getProduct().getFarmer().getName()
                                : "Unknown Farmer"
                ))
                .collect(Collectors.toList());

        Long retailerId = order.getRetailer() != null ? order.getRetailer().getId() : null;
        String retailerName = order.getRetailer() != null ? order.getRetailer().getStoreName() : null;

        String farmerName = "Unknown Farmer";
        if (order.getItems() != null && !order.getItems().isEmpty()) {
            if (order.getItems().get(0).getProduct() != null &&
                    order.getItems().get(0).getProduct().getFarmer() != null) {

                farmerName = order.getItems().get(0).getProduct().getFarmer().getName();
            }
        }

        return new OrderResponseDTO(
                order.getId(),
                order.getCreatedAt(),
                order.getTotalAmount(),
                order.getPaymentMethod(),
                order.getPaymentStatus(),
                order.getStatus(),
                items,
                retailerId,
                retailerName,
                farmerName,
                order.getTransporterId(),
                order.getVehicleType(),
                order.getVehicleNo(),
                order.getDriverName(),
                order.getDriverContact(),
                order.getDeliveredDate()
        );
    }
}
