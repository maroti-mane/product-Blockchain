package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.SignupRequest;
import com.product_blockchain.product_blockchain.entity.Farmer;
import com.product_blockchain.product_blockchain.service.FarmerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")


public class AuthController {

    @Autowired
    private FarmerService farmerService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ==================================================
    //              ✅ FARMER REGISTER
    // ==================================================
    @PostMapping("/farmer/register")
    public ResponseEntity<?> registerFarmer(@Valid @RequestBody SignupRequest signupRequest,
                                            BindingResult bindingResult) {
        Map<String, Object> response = new HashMap<>();

        // Validation errors
        if (bindingResult.hasErrors()) {
            response.put("success", false);
            response.put("message", "Validation failed");
            response.put("errors", bindingResult.getAllErrors());
            return ResponseEntity.badRequest().body(response);
        }

        try {
            // Check if farmer already exists
            if (farmerService.farmerExists(signupRequest.getEmail())) {
                response.put("success", false);
                response.put("message", "Email is already registered");
                return ResponseEntity.badRequest().body(response);
            }

            Farmer farmer = farmerService.registerFarmer(signupRequest);

            response.put("success", true);
            response.put("message", "Farmer registered successfully");
            response.put("farmer", Map.of(
                    "id", farmer.getId(),
                    "name", farmer.getName(),
                    "email", farmer.getEmail()
            ));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // ==================================================
    //              ✅ FARMER LOGIN
    // ==================================================
    @PostMapping("/farmer/login")
    public ResponseEntity<?> loginFarmer(@RequestBody Map<String, String> loginRequest) {
        Map<String, Object> response = new HashMap<>();

        String email = loginRequest.get("email");
        String password = loginRequest.get("password");

        try {
            Farmer farmer = farmerService.getFarmerByEmail(email);

            if (farmer == null) {
                response.put("success", false);
                response.put("message", "Farmer not found");
                return ResponseEntity.badRequest().body(response);
            }

            // ✅ Compare encoded password
            if (!passwordEncoder.matches(password, farmer.getPassword())) {
                response.put("success", false);
                response.put("message", "Invalid credentials");
                return ResponseEntity.badRequest().body(response);
            }

            response.put("success", true);
            response.put("message", "Login successful");
            response.put("farmer", Map.of(
                    "id", farmer.getId(),
                    "name", farmer.getName(),
                    "email", farmer.getEmail()
            ));

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
