package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.SignupRequest;
import com.product_blockchain.product_blockchain.entity.Farmer;
import com.product_blockchain.product_blockchain.repository.FarmerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FarmerService {

    @Autowired
    private FarmerRepository farmerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // -----------------------------
    // Check email exists
    // -----------------------------
    public boolean farmerExists(String email) {
        return farmerRepository.existsByEmail(email);
    }

    // -----------------------------
    // Register Farmer
    // -----------------------------
    public Farmer registerFarmer(SignupRequest request) {

        Farmer farmer = new Farmer();
        farmer.setName(request.getName());
        farmer.setEmail(request.getEmail());
        farmer.setPhone(request.getPhone());
        farmer.setAddress(request.getAddress());
        farmer.setPassword(passwordEncoder.encode(request.getPassword()));

        return farmerRepository.save(farmer);
    }

    // -----------------------------
    // Farmer Login
    // -----------------------------
    public Farmer getFarmerByEmail(String email) {
        return farmerRepository.findByEmail(email).orElse(null);
    }

    // -----------------------------
    // List all farmers
    // -----------------------------
    public List<Farmer> getAllFarmers() {
        return farmerRepository.findAll();
    }

    // -----------------------------
    // List farmers + products (Retailer Dashboard)
    // -----------------------------
    public List<Farmer> getFarmersWithProducts() {
        return farmerRepository.findAllWithProducts();
    }

    // -----------------------------
    // Get one farmer
    // -----------------------------
    public Farmer getFarmerById(Long id) {
        return farmerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Farmer not found"));
    }
}
