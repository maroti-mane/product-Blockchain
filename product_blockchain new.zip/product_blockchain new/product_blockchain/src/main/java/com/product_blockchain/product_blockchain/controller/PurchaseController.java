package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.PurchaseRequest;
import com.product_blockchain.product_blockchain.dto.PurchaseDTO;
import com.product_blockchain.product_blockchain.service.PurchaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/purchase")
@CrossOrigin(origins = "http://localhost:3000")
public class PurchaseController {

    @Autowired
    private PurchaseService purchaseService;

    @PostMapping("/buy")
    public ResponseEntity<?> buyProduct(@RequestBody PurchaseRequest request) {
        try {
            PurchaseDTO dto = purchaseService.buyProduct(request);
            return ResponseEntity.ok(dto);

        } catch (Exception e) {
            return ResponseEntity.status(500).body(
                    "Purchase failed: " + e.getMessage()
            );
        }
    }
}
