package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.entity.Farmer;
import com.product_blockchain.product_blockchain.service.FarmerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmers")

public class FarmerController {

    @Autowired
    FarmerService farmerService;

    @GetMapping("/all")
    public List<Farmer> getAllFarmers() {
        return farmerService.getAllFarmers();
    }

    @GetMapping("/with-products")
    public List<Farmer> getFarmersWithProducts() {
        return farmerService.getFarmersWithProducts();
    }

    @GetMapping("/{id}")
    public Farmer getFarmerById(@PathVariable Long id) {
        return farmerService.getFarmerById(id);
    }
}
