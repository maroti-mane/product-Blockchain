package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.CartItemRequest;
import com.product_blockchain.product_blockchain.entity.CartItem;
import com.product_blockchain.product_blockchain.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")

public class CartController {

    @Autowired
    private CartService cartService;

    // ADD TO CART
    @PostMapping("/add")
    public ResponseEntity<?> add(@RequestBody CartItemRequest request) {
        cartService.addToCart(request);
        return ResponseEntity.ok("Added to cart");
    }

    // GET CART
    @GetMapping("/{retailerId}")
    public ResponseEntity<?> getCart(@PathVariable Long retailerId) {
        return ResponseEntity.ok(cartService.getCartByRetailer(retailerId));
    }

    // UPDATE QUANTITY
    @PutMapping("/update/{itemId}")
    public ResponseEntity<?> updateQuantity(
            @PathVariable Long itemId,
            @RequestBody CartItemRequest request
    ) {
        CartItem item = cartService.updateQuantity(itemId, request.getQuantity());
        return ResponseEntity.ok(item);
    }

    // REMOVE CART ITEM
    @DeleteMapping("/remove/{itemId}")
    public ResponseEntity<?> removeItem(@PathVariable Long itemId) {
        cartService.removeItem(itemId);
        return ResponseEntity.ok("Item removed");
    }

    // CLEAR CART
    @DeleteMapping("/clear/{retailerId}")
    public ResponseEntity<?> clearCart(@PathVariable Long retailerId) {
        cartService.clearCart(retailerId);
        return ResponseEntity.ok("Cart cleared");
    }
}
