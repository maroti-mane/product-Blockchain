package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.PurchaseDTO;
import com.product_blockchain.product_blockchain.dto.PurchaseRequest;
import com.product_blockchain.product_blockchain.entity.Product;
import com.product_blockchain.product_blockchain.entity.Purchase;
import com.product_blockchain.product_blockchain.repository.ProductRepository;
import com.product_blockchain.product_blockchain.repository.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PurchaseServiceImpl implements PurchaseService {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private PurchaseRepository purchaseRepo;

    @Override
    public PurchaseDTO buyProduct(PurchaseRequest request) {

        // Get product by ID
        Product product = productRepo.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Check stock
        if (product.getQuantity() < request.getQuantity()) {
            throw new RuntimeException("Not enough stock available");
        }

        // Update product stock
        product.setQuantity(product.getQuantity() - request.getQuantity());
        productRepo.save(product);

        // Save purchase entry
        Purchase purchase = new Purchase();
        purchase.setUserId(request.getUserId());
        purchase.setProductId(request.getProductId());
        purchase.setProductName(product.getName());
        purchase.setPrice(product.getPrice());
        purchase.setQuantity(request.getQuantity());
        purchase.setPurchaseDate(LocalDateTime.now());

        purchaseRepo.save(purchase);

        // Return DTO to frontend
        PurchaseDTO dto = new PurchaseDTO();
        dto.setId(purchase.getId());
        dto.setUserId(request.getUserId());
        dto.setProductId(request.getProductId());
        dto.setProductName(product.getName());
        dto.setPrice(product.getPrice());
        dto.setQuantity(request.getQuantity());
        dto.setPurchaseDate(purchase.getPurchaseDate().toString());

        return dto;
    }
}
