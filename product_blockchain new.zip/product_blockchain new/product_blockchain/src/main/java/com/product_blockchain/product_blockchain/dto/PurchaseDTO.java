package com.product_blockchain.product_blockchain.dto;

import lombok.Data;

@Data
public class PurchaseDTO {

    private Long id;

    private Long userId;

    private Long productId;

    private String productName;

    private double price;

    private int quantity;

    private String purchaseDate;  // formatted date string
}
