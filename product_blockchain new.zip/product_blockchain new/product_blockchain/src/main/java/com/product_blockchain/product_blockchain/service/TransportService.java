package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.entity.Order;
import com.product_blockchain.product_blockchain.entity.Transport;
import com.product_blockchain.product_blockchain.entity.Transporter;
import com.product_blockchain.product_blockchain.repository.OrderRepository;
import com.product_blockchain.product_blockchain.repository.TransportRepository;
import com.product_blockchain.product_blockchain.repository.TransporterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransportService {

    @Autowired
    private TransportRepository transportRepo;

    @Autowired
    private TransporterRepository transporterRepo;

    @Autowired
    private OrderRepository orderRepo;

    public Transport assignTransport(Long orderId, Long transporterId, Transport t) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        Transporter transporter = transporterRepo.findById(transporterId)
                .orElseThrow(() -> new RuntimeException("Transporter not found"));

        t.setOrder(order);
        t.setTransporter(transporter);
        t.setStatus("ASSIGNED");

        order.setStatus("TRANSPORT_ASSIGNED");

        orderRepo.save(order);
        return transportRepo.save(t);
    }

    public Transport updateStatus(Long transportId, String status) {
        Transport transport = transportRepo.findById(transportId)
                .orElseThrow(() -> new RuntimeException("Transport not found"));

        transport.setStatus(status);

        if (status.equals("DELIVERED")) {
            Order o = transport.getOrder();
            o.setStatus("DELIVERED");
            orderRepo.save(o);
        }

        return transportRepo.save(transport);
    }

    public Transport findByOrder(Long orderId) {
        return transportRepo.findByOrderId(orderId);
    }

    public java.util.List<Transport> getByTransporter(Long id) {
        return transportRepo.findByTransporterId(id);
    }
}
