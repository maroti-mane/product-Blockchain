package com.product_blockchain.product_blockchain.service;


import com.product_blockchain.product_blockchain.dto.UserSignupRequest;
import com.product_blockchain.product_blockchain.entity.User;

public interface UserService {
    User signup(UserSignupRequest request);
    User login(String email, String password);
}



