package com.product_blockchain.product_blockchain.service;


import com.product_blockchain.product_blockchain.dto.UserSignupRequest;
import com.product_blockchain.product_blockchain.entity.User;
import com.product_blockchain.product_blockchain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repo;

    @Override
    public User signup(UserSignupRequest request) {

        if (repo.findByEmail(request.getEmail()) != null) {
            throw new RuntimeException("Email already exists");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());

        return repo.save(user);
    }

    @Override
    public User login(String email, String password) {
        User user = repo.findByEmail(email);
        if (user == null || !user.getPassword().equals(password)) {
            throw new RuntimeException("Invalid email/password");
        }
        return user;
    }
}
