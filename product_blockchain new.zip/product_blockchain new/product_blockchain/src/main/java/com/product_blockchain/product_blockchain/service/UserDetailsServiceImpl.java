package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.entity.Farmer;
import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.repository.FarmerRepository;
import com.product_blockchain.product_blockchain.repository.RetailerRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final FarmerRepository farmerRepository;
    private final RetailerRepository retailerRepository;

    public UserDetailsServiceImpl(FarmerRepository farmerRepository,
                                  RetailerRepository retailerRepository) {
        this.farmerRepository = farmerRepository;
        this.retailerRepository = retailerRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Try to find as Farmer
        Farmer farmer = farmerRepository.findByEmail(email).orElse(null);
        if (farmer != null) {
            return new org.springframework.security.core.userdetails.User(
                    farmer.getEmail(),
                    farmer.getPassword(),
                    new ArrayList<>()
            );
        }

        // Try to find as Retailer
        Retailer retailer = retailerRepository.findByEmail(email).orElse(null);
        if (retailer != null) {
            return new org.springframework.security.core.userdetails.User(
                    retailer.getEmail(),
                    retailer.getPassword(),
                    new ArrayList<>()
            );
        }

        // If neither Farmer nor Retailer found
        throw new UsernameNotFoundException("User not found with email: " + email);
    }
}