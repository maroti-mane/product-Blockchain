package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.RetailerSignupRequest;
import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.repository.RetailerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class RetailerService {

    @Autowired
    private RetailerRepository retailerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ==========================================================
    // ⭐ SIGNUP
    // ==========================================================
    public Retailer registerRetailer(RetailerSignupRequest signupRequest) {

        if (!StringUtils.hasText(signupRequest.getEmail())) {
            throw new RuntimeException("Email is required!");
        }

        if (retailerRepository.existsByEmail(signupRequest.getEmail())) {
            throw new RuntimeException("Email is already registered!");
        }

        if (!StringUtils.hasText(signupRequest.getName())) {
            throw new RuntimeException("Owner name is required!");
        }

        if (!StringUtils.hasText(signupRequest.getPassword())) {
            throw new RuntimeException("Password is required!");
        }

        Retailer retailer = new Retailer();
        retailer.setOwnerName(signupRequest.getName());
        retailer.setEmail(signupRequest.getEmail());
        retailer.setPassword(passwordEncoder.encode(signupRequest.getPassword()));
        retailer.setPhone(signupRequest.getPhone());
        retailer.setAddress(signupRequest.getAddress());

        // Store name
        if (StringUtils.hasText(signupRequest.getStoreName())) {
            retailer.setStoreName(signupRequest.getStoreName().trim());
        } else {
            retailer.setStoreName(signupRequest.getName().trim() + "'s Store");
        }

        if (StringUtils.hasText(signupRequest.getBusinessLicense())) {
            retailer.setBusinessLicense(signupRequest.getBusinessLicense().trim());
        }

        return retailerRepository.save(retailer);
    }

    // ==========================================================
    // ⭐ LOGIN – Get retailer by email
    // ==========================================================
    public Retailer getRetailerByEmail(String email) {
        return retailerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Retailer not found with email: " + email));
    }

    // ==========================================================
    // ⭐ PASSWORD VERIFY
    // ==========================================================
    public boolean checkPassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    // ==========================================================
    // ⭐ NEW — Get ALL Retailers (for User → Retailer List)
    // ==========================================================
    public List<Retailer> getAllRetailers() {
        return retailerRepository.findAll();
    }
}
