package com.product_blockchain.product_blockchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;

import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class ProductBlockchainApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductBlockchainApplication.class, args);
	}

}
