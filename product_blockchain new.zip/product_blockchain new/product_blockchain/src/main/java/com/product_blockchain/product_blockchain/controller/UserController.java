package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.dto.UserDTO;
import com.product_blockchain.product_blockchain.dto.UserLoginRequest;
import com.product_blockchain.product_blockchain.dto.UserSignupRequest;
import com.product_blockchain.product_blockchain.entity.User;
import com.product_blockchain.product_blockchain.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;  // ✅ FIXED — Add this

    @PostMapping("/signup")
    public UserDTO signup(@RequestBody UserSignupRequest request) {

        // call service to handle signup
        User saved = userService.signup(request);

        UserDTO dto = new UserDTO();
        dto.setId(saved.getId());
        dto.setName(saved.getName());
        dto.setEmail(saved.getEmail());

        return dto;
    }

    @PostMapping("/login")
    public UserDTO login(@RequestBody UserLoginRequest request) {

        User user = userService.login(request.getEmail(), request.getPassword());

        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());

        return dto;
    }
}
