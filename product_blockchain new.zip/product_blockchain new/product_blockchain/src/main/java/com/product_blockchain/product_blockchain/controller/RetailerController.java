package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.entity.Product;
import com.product_blockchain.product_blockchain.service.RetailerService;
import com.product_blockchain.product_blockchain.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/retailers")

public class RetailerController {

    @Autowired
    private RetailerService retailerService;

    @Autowired
    private ProductService productService;

    // USER → See all retailers
    @GetMapping("/all")
    public ResponseEntity<List<Retailer>> getAllRetailers() {
        return ResponseEntity.ok(retailerService.getAllRetailers());
    }

    // USER → Retailer → Retailer Stock
    @GetMapping("/{retailerId}/stock")
    public ResponseEntity<List<Product>> getRetailerStock(@PathVariable Long retailerId) {
        return ResponseEntity.ok(productService.getRetailerStock(retailerId));
    }
}
