package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.entity.Transporter;
import com.product_blockchain.product_blockchain.repository.TransporterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransporterService {

    @Autowired
    private TransporterRepository repo;

    public Transporter signup(Transporter t) {
        if (repo.findByEmail(t.getEmail()).isPresent()) {
            throw new RuntimeException("Email already registered!");
        }
        return repo.save(t);
    }

    public Transporter login(String email, String password) {
        Transporter t = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Invalid email"));

        if (!t.getPassword().equals(password)) {
            throw new RuntimeException("Invalid password");
        }

        return t;
    }

    public java.util.List<Transporter> getAll() {
        return repo.findAll();
    }
}
