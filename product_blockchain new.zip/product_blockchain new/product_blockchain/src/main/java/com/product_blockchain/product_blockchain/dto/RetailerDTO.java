package com.product_blockchain.product_blockchain.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class RetailerDTO {
    private Long id;
    private String storeName;
    private String ownerName;
    private String email;
    private String phone;
    private String address;
    private String businessLicense;
    private LocalDateTime createdAt;
}