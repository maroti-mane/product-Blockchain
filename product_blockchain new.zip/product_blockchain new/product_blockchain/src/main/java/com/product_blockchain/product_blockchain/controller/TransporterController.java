package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.entity.Transporter;
import com.product_blockchain.product_blockchain.service.TransporterService;
import com.product_blockchain.product_blockchain.service.OrderService;   // ⭐ ADD THIS
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transporters")
public class TransporterController {

    @Autowired
    private TransporterService transporterService;

    @Autowired
    private OrderService orderService;   // ⭐ ADD THIS

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody Transporter transporter) {
        return ResponseEntity.ok(transporterService.signup(transporter));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Transporter t) {
        return ResponseEntity.ok(transporterService.login(t.getEmail(), t.getPassword()));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(transporterService.getAll());
    }

    // ⭐ FIXED: use orderService instead of transporterService
    @GetMapping("/{id}/orders")
    public ResponseEntity<?> getOrdersByTransporter(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrdersForTransporter(id));
    }
}
