package com.product_blockchain.product_blockchain.repository;

import com.product_blockchain.product_blockchain.entity.Transport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransportRepository extends JpaRepository<Transport, Long> {

    List<Transport> findByTransporterId(Long transporterId);

    Transport findByOrderId(Long orderId);
}
