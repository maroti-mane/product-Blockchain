package com.product_blockchain.product_blockchain.dto;

public class TransportDTO {

    private Long id;
    private Long orderId;
    private String status;

    // -----------------------
    // Constructor
    // -----------------------
    public TransportDTO(Long id, Long orderId, String status) {
        this.id = id;
        this.orderId = orderId;
        this.status = status;
    }

    // -----------------------
    // Getters & Setters
    // -----------------------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
