package com.product_blockchain.product_blockchain.controller;

import com.product_blockchain.product_blockchain.entity.Transport;
import com.product_blockchain.product_blockchain.service.TransportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transports")
public class TransportController {

    @Autowired
    private TransportService transportService;

    // ----------------------------------------------------------
    // FARMER ASSIGNS A TRANSPORTER TO THE ORDER
    // ----------------------------------------------------------
    @PostMapping("/assign/{orderId}/{transporterId}")
    public ResponseEntity<Transport> assignTransport(
            @PathVariable Long orderId,
            @PathVariable Long transporterId,
            @RequestBody Transport transport
    ) {
        Transport assigned = transportService.assignTransport(orderId, transporterId, transport);
        return ResponseEntity.ok(assigned);
    }

    @GetMapping("/by-order/{orderId}")
    public ResponseEntity<Transport> getByOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(transportService.findByOrder(orderId));
    }

    @GetMapping("/by-transporter/{transporterId}")
    public ResponseEntity<?> getByTransporter(@PathVariable Long transporterId) {
        return ResponseEntity.ok(transportService.getByTransporter(transporterId));
    }

    @PutMapping("/{transportId}/status")
    public ResponseEntity<Transport> updateStatus(
            @PathVariable Long transportId,
            @RequestParam String status
    ) {
        return ResponseEntity.ok(transportService.updateStatus(transportId, status));
    }



}
