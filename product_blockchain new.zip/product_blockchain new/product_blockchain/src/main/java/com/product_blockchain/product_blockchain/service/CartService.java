package com.product_blockchain.product_blockchain.service;

import com.product_blockchain.product_blockchain.dto.CartItemRequest;
import com.product_blockchain.product_blockchain.entity.CartItem;
import com.product_blockchain.product_blockchain.entity.Product;
import com.product_blockchain.product_blockchain.entity.Retailer;
import com.product_blockchain.product_blockchain.repository.CartItemRepository;
import com.product_blockchain.product_blockchain.repository.ProductRepository;
import com.product_blockchain.product_blockchain.repository.RetailerRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

@Service
@Transactional
public class CartService {

    private final CartItemRepository cartRepo;
    private final ProductRepository productRepo;
    private final RetailerRepository retailerRepo;

    public CartService(CartItemRepository cartRepo, ProductRepository productRepo, RetailerRepository retailerRepo) {
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
        this.retailerRepo = retailerRepo;
    }

    // ADD TO CART
    public CartItem addToCart(CartItemRequest req) {

        Retailer retailer = retailerRepo.findById(req.getRetailerId())
                .orElseThrow(() -> new RuntimeException("Retailer not found"));

        Product product = productRepo.findById(req.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        CartItem existing = cartRepo.findByRetailer_IdAndProduct_Id(retailer.getId(), product.getId());

        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + req.getQuantity());
            return cartRepo.save(existing);
        }


        CartItem item = new CartItem();
        item.setRetailer(retailer);
        item.setProduct(product);
        item.setQuantity(req.getQuantity());



        return cartRepo.save(item);
    }





    // GET CART  (CONTROLLER EXPECTS THIS NAME)
    public List<CartItem> getCartByRetailer(Long retailerId) {
        List<CartItem> items = cartRepo.findByRetailer_Id(retailerId);
        return (items == null || items.isEmpty()) ? List.of() : items;
    }

    // UPDATE QUANTITY
    public CartItem updateQuantity(Long itemId, Integer quantity) {
        CartItem item = cartRepo.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        item.setQuantity(quantity);

        return cartRepo.save(item);
    }

    // REMOVE ONE ITEM
    public void removeItem(Long id) {
        cartRepo.deleteById(id);
    }

    // CLEAR CART (CONTROLLER EXPECTS clearCart)
    public void clearCart(Long retailerId) {
        cartRepo.deleteByRetailer_Id(retailerId);
    }
}
